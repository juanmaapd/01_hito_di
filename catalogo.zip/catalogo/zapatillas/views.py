from django.shortcuts import render
from zapatillas.models import Zapatillas

def zapatillas(request):
    zapatillas = Zapatillas.objects.all()
    context = {
        'zapatillas': zapatillas
    }
    return render(request, 'zapatillas.html', context)

def zapatillas_detail(request, pk):
    project = Zapatillas.objects.get(pk=pk)
    context = {
        'project': project
    }
    return render(request, 'zapatillas_detail.html', context)

def home(request):
    return render (request, 'home.html', {})