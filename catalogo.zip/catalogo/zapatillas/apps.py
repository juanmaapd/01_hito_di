from django.apps import AppConfig


class ZapatillasConfig(AppConfig):
    name = 'zapatillas'
