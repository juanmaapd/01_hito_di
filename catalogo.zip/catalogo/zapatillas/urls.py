from django.urls import path
from zapatillas import views

urlpatterns = [
    path('', views.home, name='home'),
    path('zapatillas/', views.zapatillas, name='zapatillas'),
    path("<int:pk>/", views.zapatillas_detail, name="zapatillas_detail"),
]